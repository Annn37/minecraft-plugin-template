package com.example.rpgskill;

import org.bukkit.entity.Player;

public interface Skill {
    void activate(Player player);
}
